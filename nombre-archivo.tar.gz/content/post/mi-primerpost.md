+++
draft = true
date = "2017-01-23T18:21:30-02:00"
title = "mi primerpost"

+++
 Este post en principio no tiene contenido voy a escribir algunos posts
en español y otros en ingles asi que a manejarse vamo los pibe
